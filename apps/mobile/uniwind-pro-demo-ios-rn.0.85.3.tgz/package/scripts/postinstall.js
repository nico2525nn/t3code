import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = dirname(fileURLToPath(import.meta.url))
const pkgPath = join(__dirname, '../package.json')
const pkg = JSON.parse(readFileSync(pkgPath, 'utf8'))
const version = pkg.version

console.log('\x1b[32m%s\x1b[0m', `Uniwind Pro${version ? ` ${version}` : ''} is already installed.`)
